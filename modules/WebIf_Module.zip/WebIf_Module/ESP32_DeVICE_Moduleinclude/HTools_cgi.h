#ifndef HTools_CGI_H
#define HTools_CGI_H

#include "SCDE_s.h"



int ReadFullFlash_cgi(WebIf_HTTPDConnSlotData_t *conn);



#endif /* HTools_CGI_H */
