#ifndef ESP32_SCDE_WEBIF_GET_CB_H
#define ESP32_SCDE_WEBIF_GET_H

//#include "WebIf_Module.h"



int ESP32_SCDE_WEBIF_get(WebIf_HTTPDConnSlotData_t* conn);



#endif // ESP32_SCDE_WEBIF_GET_CB_H
