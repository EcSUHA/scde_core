#ifndef StationCfg_jso_H
#define StationCfg_jso_H

#include "WebIF_Module.h"



int StationCfg_jso(WebIF_HTTPDConnSlotData_t *conn) ;



#endif /* StationCfg_jso_H */
