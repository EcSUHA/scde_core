#ifndef CGI_NOTFOUNDERR_H
#define CGI_NOTFOUNDERR_H

#include "WebIf_Module.h"



int NotFoundErr_cgi(WebIf_HTTPDConnSlotData_t *conn);



#endif /* CGI_NOTFOUNDERR_H */

