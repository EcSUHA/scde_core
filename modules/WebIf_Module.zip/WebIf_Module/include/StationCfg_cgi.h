#ifndef StationCfg_cgi_H
#define StationCfg_cgi_H

#include "WebIF_Module.h"



int StationCfg_cgi(WebIF_HTTPDConnSlotData_t *connData);



#endif /* StationCfg_cgi_H */
