#ifndef WEBIF_ESPFSSTDFILETX_H
#define WEBIF_ESPFSSTDFILETX_H

#include "WebIf_Module.h"
//#include "Espfs.h"



int WebIF_EspFSStdFileTX(WebIf_HTTPDConnSlotData_t *conn);



#endif /*WEBIF_ESPFSSTDFILETX*/
