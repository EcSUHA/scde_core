﻿// SCDE-Module Telnet

#ifndef WEBIF_MODULE_GLOBAL_H
#define WEBIF_MODULE_GLOBAL_H



#include "SCDE_s.h"



// Data 'Provided By Module' for the telnet module - we need this from SCDE
//const  ProvidedByModule_t WebIf_ProvidedByModule;



#endif /*WEBIF_MODULE_GLOBAL_H*/
