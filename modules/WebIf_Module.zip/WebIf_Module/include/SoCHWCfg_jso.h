#ifndef SoCHWCfg_jso_H
#define SoCHWCfg_jso_H

#include "WebIF_Module.h"



int SoCHWCfg_jso(WebIF_HTTPDConnSlotData_t *conn) ;




#endif /* SoCHWCfg_jso_H */
