#ifndef TiStCfg_jso_H
#define TiStCfg_jso_H

#include "WebIF_Module.h"



int TiStCfg_jso(WebIF_HTTPDConnSlotData_t *conn) ;




#endif /* TiStCfg_jso_H */
