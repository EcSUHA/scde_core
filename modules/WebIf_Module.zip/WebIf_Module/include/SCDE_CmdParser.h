﻿#ifndef SCDE_CmdParser_H
#define SCDE_CmdParser_H




int SCDE_FeatCmdParser(WebIf_HTTPDConnSlotData_t *conn, char* Args, uint16_t ADID, char** RespArgsWPosX, char** HdrFldsWPosX, char** BdyDataWPosX);

#endif /* SCDE_CmdParser_H */

